from fastapi import FastAPI
import os

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Version 2.0 - Backend Updated!"}

@app.get("/status")
def status():
	return{"status": "API Running", "host": os.getenv("HOSTNAME")}